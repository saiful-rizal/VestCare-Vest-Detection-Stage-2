import React from "react";
import ReactDOM from "react-dom/client";
import "./assets/css/nucleo-icons.css";
import "./assets/css/nucleo-svg.css";
import "./index.css";
import App from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
